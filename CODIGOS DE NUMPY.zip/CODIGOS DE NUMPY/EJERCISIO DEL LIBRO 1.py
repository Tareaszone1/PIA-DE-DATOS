#importamos la librería numpy, y le damos como nombre np dentro del programa
import numpy as np
lista=[25,12,15,66,12.5]
vector=np.array(lista)
print(vector)