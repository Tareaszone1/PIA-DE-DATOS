import pandas as pd

s = pd.Series(['Matematicas', 'historia', 'economia', 'programacion', 'ingles'], dtype='string')
print(s)
