import pandas as pd

s = pd.Series ([1,2,3,4])
print(s*2)
print(s%2)
s = pd.Series(['a', 'b', 'c'])
print(s*5)