import pandas as pd
# Importación del fichero datos-colesteroles.csv
df = pd.read_csv(
'https://raw.githubusercontent.com/asalber/manual-python/master/datos/colesteroles.csv', sep=';', 
decimal=',')
print(df.head())
