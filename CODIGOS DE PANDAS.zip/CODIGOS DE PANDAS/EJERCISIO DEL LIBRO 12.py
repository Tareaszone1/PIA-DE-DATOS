import pandas as pd

datos = {
    'Nombre': ['Maria', 'Luis', 'Carmen', 'Antonio'],
    'edad': [18, 22, 20, 21],
    'grado': ['Economia', 'Medicina', 'Arquitectura', 'Economia'],
    'correo': ['Maria@gmail.com', 'luis@yahoo.com', 'carmen@gmail.com', 'Antonio@gmail.com']
}
df = pd.DataFrame(datos)
print(df)
