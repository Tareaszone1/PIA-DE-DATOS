import pandas as pd
df = pd.DataFrame([['María', 18], ['Luis', 22], 
['Carmen', 20]], columns=['Nombre', 'Edad'])
print(df)
