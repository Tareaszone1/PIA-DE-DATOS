import pandas as pd

s = pd.Series({'Matematicas': 6.0, 'economia': 4.5, 'programacion': 8.5})
print(s)
print(s[1:3])
print(s['economia'])
print(s[['programacion', 'Matematicas']])
