import pandas as pd
df = pd.DataFrame(np.random.randn(4, 3), 
columns=['a', 'b', 'c'])
print(df)
