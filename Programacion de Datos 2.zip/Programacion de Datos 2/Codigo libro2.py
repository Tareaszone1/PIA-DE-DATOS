conjunto={1,2,3,4}
print(conjunto)
# Se agrega el número 5
conjunto.add(5)
print(conjunto)
# Se agrega de nuevo el 5, pero no tiene ningún efecto
conjunto.add(5)
print(conjunto)