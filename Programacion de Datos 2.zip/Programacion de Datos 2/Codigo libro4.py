conjunto_A={1,2,3,4,5}
conjunto_B={4,5,6,7,8}
repetidos=conjunto_A.intersection(conjunto_B)
diferentes=conjunto_A.difference(conjunto_B)
print(repetidos)
print(diferentes)