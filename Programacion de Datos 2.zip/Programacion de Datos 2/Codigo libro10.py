numeros=(1,2,3,4,5,2,3,4,2,1,2)
valor_buscado=2
primera_ocurrencia=numeros.index(valor_buscado)
print(f"Se buscó <{valor_buscado}>, y se encontró en {primera_ocurrencia}")
print(f"El valor buscado está {numeros.count(valor_buscado)} veces.")