dias=("lun", "mar","mié","jue","vie", "sáb","dom")
# Recupera el elemento con el índice 3
print(dias[3])
# Recupera el rango de elementos, del índice 2 al 4, excluyendo el final.
print(dias[2:4])
# Recupera el rango de elementos, del índice 2 y hasta el último elemento.
print(dias[2:])
# Recupera el rango de elementos, del primer elemento y hasta el elemento 
# con el índice 2, sin incluirlo.
print(dias[:2])
# Recupera el primer elemento, de atrás hacia adelante.
print(dias[-1])
# Recupera el segundo elemento, de atrás hacia adelante.
print(dias[-2])
# Recupera el rango de elementos, cuarto elemento de atrás hacia adelante,
# hasta el segundo elemento de atrás hacia adelante, sin incluirlo.
# Tomar en cuenta que las lecturas, aunque sean negativas, se hacen de
# izquierdaa derecha.
print(dias[-4:-2])
