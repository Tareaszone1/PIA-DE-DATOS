# Declara un diccionario vacío, de nombre Asistentes
Asistentes={}

# Agrega los elementos existentes.
Asistentes["1234"] = ["1234","Juan",100.00]
Asistentes["2345"] = ["2345","María",400.00]
Asistentes["3456"] = ["3456","Brenda",350.00]

# Muestra el contenido del diccionario.
print(Asistentes)

# Menú general del programa.
print("\nMenú de opciones:")
print("\t[A] Agregar")
print("\t[B] Buscar")
print("\t[E] Eliminar elemento")
print("\t[M] Modificar elemento")
print("\t[V] Ver datos")
print("\t[Q] Quitar todos los elementos de la lista")
print("\t[S] Salir")

# Inicia un ciclo infinito, para controlar el programa.
while True:
    # Pregunta la opción de menú. Usa una variable llamada opcion
    opcion = input("\n¿QUÉ DESEAS HACER?: ").upper()

    # Valida si se capturó una opción válida (ABEMVQS)
    # o de lo contrario, muestra mensaje y vuelve a preguntar. 
    if not opcion in "ABEMVQS":
        print("Opción no válida, intenta de nuevo.")
        continue

    # Opción: Salir
    if opcion == "S":
        print("Fin de la ejecución.")
        break

    # Opción: Agregar asistente
    if opcion == "A":
        socio = input("Número de socio a agregar: ")
        if socio not in Asistentes:
            nombre = input("Nombre del socio: ")
            aportacion = float(input("Aportación: "))
            Asistentes[socio] = [socio,nombre,aportacion]
            print("Asistente agregado.")
        else:
            print("Asistente encontrado. No se puede repetir.")

    # Opción: Buscar asistente
    if opcion == "B":
        socio = input("Número de socio a buscar: ")
        recuperado = Asistentes.get(socio)
        if recuperado is None:
            print("Asistente no encontrado.")
        else:
            print(f"{recuperado[0]},{recuperado[1]},{recuperado[2]}")

    # Eliminar asistente
    if opcion == "E":
        socio = input("Número de socio a eliminar: ")
        if socio not in Asistentes:
            print("Asistente no encontrado. No se puede eliminar.")
        else:
            del Asistentes[socio]
            print("Asistente eliminado.")

    # Opción: Modificar asistente
    if opcion == "M":
        socio = input("Número de socio a modificar: ")
        recuperado = Asistentes.get(socio)
        if recuperado is None:
            print("Asistente no encontrado. No se puede modificar")
        else:
            print(f"Datos actuales: {recuperado[0]},{recuperado[1]},{recuperado[2]}")
            nombre = input("Nuevo nombre del socio: ")
            aportacion = float(input("Nueva aportación: "))
            Asistentes[socio] = [socio,nombre,aportacion]
            print("Asistente modificado.")

    # Ver diccionario
    if opcion == "V":
        acumulado = sum(v[2] for v in Asistentes.values())
        print(f"Elementos en la lista: {len(Asistentes)} ")
        for v in Asistentes.values():
            print(f"{v[0]},{v[1]},{v[2]}")
        print(f"Acumulado: ${acumulado:.2f} ")

    # Quitar todos los elementos
    if opcion == "Q":
        Asistentes.clear()
        print("Todos los asistentes eliminados.")
