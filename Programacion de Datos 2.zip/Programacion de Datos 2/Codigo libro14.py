# Declarar una lista en blanco
lista_vacia=[]
# Declarando una lista de valores
dias=["lunes", "martes","miércoles",
 "jueves","viernes","sábado","domingo"]
print(dias)
print(type(dias))
# Cambio de valores
# Cambio a un solo elemento
dias[1]="MARTES"
print(dias)
# Cambio de un rango de valores
dias[2:4]=["MIERCOLES","JUEVES"]
print(dias)
# Cambio 1 valor, por varios.
dias[4:]=["VIERNES"]
print(dias)
dias[0]="LUNES"
print(dias)
