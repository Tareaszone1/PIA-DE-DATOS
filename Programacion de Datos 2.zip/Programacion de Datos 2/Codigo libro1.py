conjunto={1,2,3,4}
print(conjunto)
print(type(conjunto))
print(f"La colección tiene {len(conjunto)} elementos.")