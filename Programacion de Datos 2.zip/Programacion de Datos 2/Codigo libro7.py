dias=("lun", "mar","mié","jue","vie", "sáb","dom")
print(dias)
print(f"El elemento en el índice 2 es: {dias[2]}")
