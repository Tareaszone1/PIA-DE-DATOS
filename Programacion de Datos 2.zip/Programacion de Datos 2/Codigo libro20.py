meses=["Enero", "Febrero","Marzo"]
# Asignación uno a uno. Por cada valor en la lista
# hay una variable receptora de valores.
(x,y,z)=meses
print(x)
print(y)
print(z)
# La siguiente instrucción produce error, porque son 3 
# elementos en la colección, pero solo hay dos variables
# receptoras.
# (x,y)=meses
