dias={"lunes", "martes","miércoles",
 "jueves","viernes","sábado","domingo"}
for dia in dias:
 print(dia)
