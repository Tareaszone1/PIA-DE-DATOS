conjunto_A={1,2,3,4,5}
conjunto_B={4,5,6,7,8}
# Unión de conjuntos, en uno nuevo
conjunto_C=conjunto_A.union(conjunto_B)
print(conjunto_A)
print(conjunto_B)
print(conjunto_C)
# Unión de conjuntos, en uno existente.
print("------------------------------")
print(conjunto_A)
conjunto_A.update(conjunto_B)
print(conjunto_A)
