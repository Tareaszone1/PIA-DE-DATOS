meses=["Enero", "Febrero","Marzo","Abril", "Mayo"]
# Se tienen menos variables receptoras, que elementos.
# Se asigna a x el primer valor, a y el segundo valor,
# y a z todos los valores que falten, en forma de lista.
(x,y,*z)=meses
print(x)
print(y)
print(z)