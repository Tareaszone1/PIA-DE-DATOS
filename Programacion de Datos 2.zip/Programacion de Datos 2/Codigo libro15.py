dias=["lunes", "martes","miércoles",
 "jueves","viernes","sábado","domingo"]
print(dias)
# Agregar un elemento
dias.append("otro")
print(dias)
# Insertar elemento
dias.insert(2,"Otro más")
print(dias)
# Mostrar el índice de un elemento.
print(dias.index("otro"))
# Mostrar el valor de un elemento, teniendo su índice.
print(dias[3])
# Eliminar un elemento por su indice
dias.pop(8)
print(dias)
# Eliminar un elemento usando su valor 
dias.remove("Otro más")
print(dias)
# Si se intenta una eliminación de un elemento que no está, se causa error.
# Si se usa pop() y no se especifica índice, se borra el último
dias.pop()
print(dias)
# Quitar todos los elementos de la lista: clear()
dias.clear()
print(dias)
