peliculas={
 10:"The Godfather",
 20:"Jurassic Park",
 30:"Ex-Machina",
 40:"The Notebook"
}
print(len(peliculas))
print(peliculas.keys())
print(peliculas.values())
print(peliculas[40])
print(peliculas.get(40))
print(peliculas.items())
print(peliculas)
# Agregar elemento por asignación
peliculas[50]="Star Wars"
# Agregar elemento usando update()
peliculas.update({60:"Unknown"})
print(peliculas)
# Actualizar el valor de un elemento
peliculas[60]="Casino Royale"
print(peliculas)
print(peliculas)
# Eliminando la última agregada
peliculas.popitem()
print(peliculas)
# Eliminando un elemento específico
peliculas.pop(20)
print(peliculas)
# Eliminando un elemento específico
del peliculas[30]
print(peliculas)
llave_a_eliminar=20
if (not llave_a_eliminar in peliculas.keys()):
 print("Ese elemento no existe")
else:
 peliculas.pop(llave_a_eliminar)
...
for llave in peliculas:
    print(llave)
for llave in peliculas:
    print(peliculas[llave])
for llave in peliculas.keys():
    print(llave)
for valor in peliculas.values():
    print(valor)
for llave,valor in peliculas.items():
    print(f"A la llave {llave} le corresponde el valor {valor}")
...

 # Demostrando que la simple asignación no genera una copia
print(peliculas)
lo_mismo=peliculas
peliculas[80]="Fifth Element"
print(lo_mismo)
# Ambos nombres de variable permiten llegar a los mismos
# datos en memoria.
# Generando copia usando copy()
peliculas_1 = peliculas.copy()
peliculas_1[90]="Toy Story"
print(peliculas)
print(peliculas_1)
peliculas_2=dict(peliculas)
peliculas_2[90]="Sharknado"
print(peliculas)
print(peliculas_2)
