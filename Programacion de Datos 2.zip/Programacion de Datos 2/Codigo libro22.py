meses=["Enero", "Febrero","Marzo","Abril", "Mayo"]
# Se tienen menos variables receptoras, que elementos.
# Se asigna a x el primer valor, a y el segundo valor,
# y a w todos los valores menos el último, en forma de lista,
# y a z el último valor.
(x,y,*w,z)=meses
print(x)
print(y)
print(w)
print(z)