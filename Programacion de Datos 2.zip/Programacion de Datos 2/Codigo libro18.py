# Diferentes maneras de copiar una lista.
numeros=[10,20,30]
# x es iguall a numeros
x=numeros
print(x)
print(type(x))
# x es una copia de numeros
x=numeros.copy()
print(x)
print(type(x))
# Gernera una lista a partir de numeros, 
# y se asigna a x
x=list(numeros)
print(x)
print(type(x))
