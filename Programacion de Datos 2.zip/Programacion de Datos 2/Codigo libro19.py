lista_1=[1,2,3,4,5]
lista_2=[4,5,6]
# Unión usando +
lista_3=lista_1+lista_2
print(lista_3)
# Extiendo los elementos de lista_1, 
# agregándole los elementos de lista_2
lista_1.extend(lista_2)
print(lista_1)