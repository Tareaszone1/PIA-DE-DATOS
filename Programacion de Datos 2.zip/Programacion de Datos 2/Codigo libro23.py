# Genera una lista que contenga 3 listas
# con datos de productos.
productos=[
 [1234,"Tuerca X",123.49],
 [2345,"Tornillo Y",234.39,"Tipo A"],
 [3882,"Lija W",3892.50]
]
for lista in productos:
    print("--------------------------")
    for elemento in lista:
        print(elemento)
