tupla_texto=("Uno","Dos","Tres")
tupla_numero=(1,2,3)
conjunto=tupla_texto+tupla_numero
print(conjunto)
print(tupla_texto*2)
print(tupla_numero*2)
