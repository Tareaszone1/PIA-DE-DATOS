x=("Hola")
print(type(x))
y=("Hola",)
print(type(y))