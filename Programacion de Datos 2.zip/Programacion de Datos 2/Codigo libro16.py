# Cadena con múltiples valores, usando ";" como separador.
pelis_favoritas="Eyes wide shut;The Godfather;The Professional;The Notebook"
favoritas = pelis_favoritas.split(';')
print(favoritas)
print(type(favoritas))
# Cadena con múltiples valores, estilo CSV con pipe-line.
pelis_favoritas="|Eyes wide shut|The Godfather|The Professional|The Notebook|"
favoritas = pelis_favoritas[1:-1].split('|')
print(favoritas)
print(type(favoritas))
