conjunto_A={1,2,3,4,5}
conjunto_C=conjunto_A
conjunto_D=conjunto_A.copy()
print(conjunto_C)
print(conjunto_D)