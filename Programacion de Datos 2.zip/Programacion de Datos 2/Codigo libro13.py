# Declarar una lista en blanco
lista_vacia=[]
# Declarando una lista de valores
dias=["lunes", "martes","miércoles",
 "jueves","viernes","sábado","domingo"]
print(dias)
print(type(dias))
