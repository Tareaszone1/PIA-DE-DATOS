# Menú general del programa.
print("\nMenú de opciones:")
print("\t[A] Agregar")
print("\t[B] Buscar")
print("\t[E] Eliminar elemento")
print("\t[V] Ver lista")
print("\t[Q] Quitar todos los elementos de la lista")
print("\t[S] Salir")

# Declara una lista vacía, de nombre Asistentes
Asistentes=[]

# Inicia un ciclo infinito, para controlar el programa.
while True:
    # Pregunta la opción de menú. Usa una variable
    # llamada opcion
    opcion=input("\n¿QUÉ DESEAS HACER?: ")

    # Valida si se capturó una opción válida (ABEVQS)
    # o de lo contrario, muestra mensaje y vuelve a preguntar. 
    # Usa upper() para homologar a mayúsculas lo capturado, y usa
    # el operador in.
    if (not opcion.upper() in "ABEVQS"):
        print("Opción no válida, intenta de nuevo.")
        continue

    # Opción: Salir
    # Si la opción es "S", imprime mensaje de salida, y se
    # sale del ciclo general usando break. 
    # Es el fin del programa.
    if (opcion.upper()=="S"):
        print("Fin de la ejecución.")
        break

    # Opción: Agregar asistente
    # Si la opción es "A", agrega uno o varios asistentes.
    # Se agregarán, mientras no se omita el asistente.
    if (opcion.upper()=="A"):
        # Abre un ciclo infinito.
        while True:
            # Pregunta el nombre del asistente.
            asistente=input("Asistente a agregar: ")
            # Si se omite el nombre, sale del ciclo.
            if (asistente==""):
                break 
            # Si no hay un elemento con ese nombre
            # se agrega el elemento, y se imprime un mensaje
            # De lo contrario, manda mensaje.
            # Usa count() para saber si hay coincidencias, y
            # append() para agregar elementos.
            if Asistentes.count(asistente)==0: 
                Asistentes.append(asistente)
                print("Asistente agregado.")
            else:
                print("Asistente encontrado. No se puede repetir.")

    # Opción: Buscar asistente
    # Si la opción es "B", busca el asistente y muestra su índice.
    if (opcion.upper()=="B"):
        # Se pregunta el asistente.
        asistente=input("Asistente a buscar: ")
        # Si el asistente no existe, mandar mensaje.
        # De lo contrario, recupera el índice.
        # Muestra mensaje, y el índice.
        # Usa count() para saber si hay coincidencias,
        # e index(), para saber la posición del elemento buscado.
        if Asistentes.count(asistente)==0:
            print("Asistente no encontrado.")
        else:
            posicion=Asistentes.index(asistente)
            print(f"Asistente encontrado. Índice {posicion}")

    # Eliminar asistente
    # Si la opción es "E", busca el asistente y lo elimina.
    if (opcion.upper()=="E"):
        # Se pregunta el asistente.
        asistente=input("Asistente a eliminar: ")
        # Si el asistente no existe, mandar mensaje.
        # De lo contrario, elimina el asistente y manda mensaje.
        # Usa count() para saber si hay coincidencias,
        # y remove(), para eliminar el elemento a partir de su valor. 
        if Asistentes.count(asistente)==0:
            print("Asistente no encontrado. No se puede eliminar.")
        else:
            Asistentes.remove(asistente)
            print("Asistente eliminado.")

    # Ver lista
    # Si la opción es "V", muestra cuántos elementos tiene la lista
    # y sus elementos.
    if (opcion.upper()=="V"):
        # Muestra cuántos elementos tiene la lista.
        print(f"Elementos en la lista: {len(Asistentes)} ")
        for a in Asistentes:
            print("-->", a)

    # Quitar todos los elementos
    # Si la opción es "Q", elimina todos los elementos de la
    # lista, y manda mensaje.
    if (opcion.upper()=="Q"):
        # Elimina todos los elementos de la lista
        Asistentes.clear()
        # Muestra mensaje
        print("Todos los asistentes eliminados.")