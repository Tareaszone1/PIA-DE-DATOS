# Ordenando el contenido de una lista
dias=["lunes", "martes","miércoles",
 "jueves","viernes","sábado","domingo"]
dias.sort()
print(dias)
dias.sort(reverse=True)
print(dias)
dias.reverse()
print(dias)
