numeros_producto=(10, 20, 30)
nombres_producto=("Producto 10", "Producto 20", "Producto 30")
precios_producto=(100.20,550.98,2543.20)
producto_buscado=20
# Primero se valida si hay al menos una coincidencia.
if numeros_producto.count(producto_buscado)>0:
 # Si hay al menos una coincidencia, se recuperan valores.
 indice=numeros_producto.index(producto_buscado)
 print(f"Numero de producto: {numeros_producto[indice]}")
 print(f"Nombre de producto: {nombres_producto[indice]}")
 print(f"Precio de producto: ${precios_producto[indice]:,.2f}")
else:
 print("No se encontró el producto")
